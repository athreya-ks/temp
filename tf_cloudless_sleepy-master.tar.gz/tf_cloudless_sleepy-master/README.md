# tf_cloudless_sleepy - v 2.0.0
A Terraform module that doesn't make use of cloud providers and just sleeps. Used to simulate (time-wise) a Terraform provisioning use case  
